/*OPERATORS

1. Multiplica 10 por 5 y muestra el resultado mediante alert.
*/

var resultado1 = 10 * 5;
alert(resultado1); 

/*
2. Divide 10 por 2 y muestra el resultado en un alert.
*/

var resultado2 = 10/5;
alert(resultado2);

/*
3. Muestra mediante un alert el resto de dividir 15 por 9
*/

var resultado3 = 15 % 9;
alert(resultado3);

/*
4. Usa el correcto operador de asignación que resultará en x = 15, teniendo dos variables y = 10 y z = 5.
*/

var y = 10;
var z = 5;

var x = y + z;  

/*
5. Usa el correcto operador de asignación que resultará en x = 50, teniendo dos variables y = 10 y z = 5.
*/

let y = 10;
let z = 5;

let x = y * z;  


