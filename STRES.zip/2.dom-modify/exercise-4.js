const p = document.createElement('p');
const txt = document.createTextNode('Soy dinámico!');
p.append(txt);
console.log(p);