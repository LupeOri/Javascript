const div = document.createElement('div');
document.body.append(div);
console.log(div);