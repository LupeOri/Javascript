const eliminados = document.querySelectorAll('.fn-remove-me');
console.log(eliminados);

for (eliminado of eliminados){
eliminado.remove();
}


