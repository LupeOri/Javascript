const div  = document.createElement('div');
const p = document.createElement('p');
div.append(p);
console.log(div);