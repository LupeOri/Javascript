const title = document.querySelector('.fn-insert-here');
const newTitle = document.createTextNode('Wubba Lubba dub dub');
title.append(newTitle);
console.log(title);