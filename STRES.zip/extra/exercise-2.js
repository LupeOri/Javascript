const elementToRemove = document.querySelector('.fn-remove-me');
elementToRemove.remove();
