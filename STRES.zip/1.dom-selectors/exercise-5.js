const testMe = document.querySelectorAll('[data-function="testMe"]');
for (const elementTestMe of testMe){
    console.log(elementTestMe);
}
