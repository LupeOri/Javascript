let showme = document.querySelector('.showme');
console.log(showme);