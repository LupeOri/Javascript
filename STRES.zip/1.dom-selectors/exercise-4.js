const pokemon = document.querySelectorAll(".pokemon");
for (let i = 0; i < pokemon.length; i++){
    console.log(pokemon[i]);
}
