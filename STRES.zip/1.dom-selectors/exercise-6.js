var personajeTres = document.querySelectorAll('[data-function="testMe"]');
console.log(personajeTres[2].textContent);

/* OTRA SOLUCION 

var thirdCharacter = document.querySelector('body :nth-child(3)');
console.log(thirdCharacter.textContent);

*/