const parrafos = document.querySelectorAll("p");
for (let i = 0; i < parrafos.length; i++){
    console.log(parrafos[i]);
}
