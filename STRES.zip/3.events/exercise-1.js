const button = document.getElementById('btnToClick');
button.addEventListener('click', function(clickEvent){
    console.log(clickEvent);
})